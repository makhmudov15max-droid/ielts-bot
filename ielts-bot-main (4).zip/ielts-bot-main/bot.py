import asyncio
import logging
import sys
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.redis import RedisStorage
import redis.asyncio as redis
import os

from config import BOT_TOKEN
from Handlers.start import start_router, auto_task_scheduler, init_all_handlers
from Handlers.teachers_sheets import sheets_router, set_users_roles as set_teachers_users_roles
from Handlers.group_report import report_router, set_users_roles as set_report_users_roles
from Handlers.tasks import tasks_router
from Handlers.admin_report import admin_report_router, init_admin_report_handler
from Handlers.settings import settings_router, init_settings_handler
from Handlers.employees import employees_router
from Handlers.salaries import salaries_router
from Handlers.callback_handlers import callback_router
from Handlers.proofs import proofs_router, init_proofs_handler
from utils.database import init_db, close_db
from utils.users_db import load_users
from utils.tasks_db import load_tasks

# ================= LOGGING =================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(name)s | %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logging.getLogger("aiogram").setLevel(logging.WARNING)

logging.info("🚀 Bot ishga tushmoqda...")


async def main():
    try:
        ADMIN_ID = 6500594896
        
        # PostgreSQL ni ulash
        await init_db()
        
        # Redis ni ulash (FSM uchun)
        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
        redis_client = redis.from_url(redis_url)
        storage = RedisStorage(redis=redis_client)
        
        logging.info("📡 Ma'lumotlar yuklanmoqda...")
        USERS_ROLES = await load_users(ADMIN_ID)
        TASKS_DATABASE = await load_tasks()
        logging.info(f"✅ {len(USERS_ROLES)} ta foydalanuvchi, {len(TASKS_DATABASE)} ta vazifa yuklandi")
        
        # Global users roles ni teachers_sheets va group_report ga o'tkazish
        set_teachers_users_roles(USERS_ROLES)
        set_report_users_roles(USERS_ROLES)
        
        # Barcha handlerlar uchun global o'zgaruvchilarni o'rnatish
        init_all_handlers(USERS_ROLES, TASKS_DATABASE, ADMIN_ID)
        init_proofs_handler(USERS_ROLES, ADMIN_ID)
        init_admin_report_handler(USERS_ROLES)
        init_settings_handler(USERS_ROLES)
        
        bot = Bot(token=BOT_TOKEN)
        dp = Dispatcher(storage=storage)
        
        # Routerlarni ulash
        dp.include_router(start_router)
        dp.include_router(tasks_router)
        dp.include_router(employees_router)
        dp.include_router(salaries_router)
        dp.include_router(callback_router)
        dp.include_router(proofs_router)
        dp.include_router(sheets_router)
        dp.include_router(report_router)
        dp.include_router(admin_report_router)
        dp.include_router(settings_router)
        
        logging.info("✅ Barcha routerlar ulandi")
        
        # Taymerni ishga tushirish
        asyncio.create_task(auto_task_scheduler(bot))
        logging.info("⏰ Task scheduler ishga tushdi")
        
        logging.info("✅ Bot polling boshlandi")
        await dp.start_polling(bot)
        
    except Exception as e:
        logging.critical(f"Bot ishga tushishda xatolik: {e}", exc_info=True)
    finally:
        await close_db()
        logging.info("🛑 Bot to'xtatildi")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logging.info("👋 Bot foydalanuvchi tomonidan to'xtatildi")
    except Exception as e:
        logging.critical(f"Kutilmagan xatolik: {e}", exc_info=True)
        sys.exit(1)
